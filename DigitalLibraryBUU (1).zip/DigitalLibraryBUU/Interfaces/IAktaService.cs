﻿using DigitalLibraryBUU.Models;

namespace DigitalLibraryBUU.Services
{
    public interface IAktaService
    {
        List<Aktum> Akta { get; set; }

        Task<List<Aktum>> GetAllAktaAsync();
        Task<Aktum> GetAktaAsync(int Id);
        Task<bool> AddAktaAsync(Aktum Akta);
        Task<bool> UpdateAktaAsync(Aktum Akta, int Id);
        Task<bool> DeleteAktaAsync(Aktum Akta);
    }
}
