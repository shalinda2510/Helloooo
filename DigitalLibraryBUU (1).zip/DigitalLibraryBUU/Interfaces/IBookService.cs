﻿using DigitalLibraryBUU.Models;

namespace DigitalLibraryBUU.Interfaces
{
    public interface IBookService
    {
        List<Buku> Bukus { get; set; }
       
        Task<bool> AddBookAsync(Buku buku);
        Task<bool> UpdateBookAsync(Buku buku, int Id);
        Task<bool> DeleteBookAsync(Buku buku);
        Task<List<Buku>> GetAllBooksAsync();
        Task<Buku> GetBookAsync(int Id);

      
    }
}
