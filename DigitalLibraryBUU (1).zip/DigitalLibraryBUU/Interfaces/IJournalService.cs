﻿using DigitalLibraryBUU.Models;

namespace DigitalLibraryBUU.Interfaces
{
    public interface IJournalService
    {
        List<Jurnal> jurnal { get; set; }

        Task<List<Jurnal>> GetAllJournalAsync();
        Task<Jurnal> GetJournalAsync(int Id);
        Task<bool> AddJournalAsync(Jurnal jurnal);
        Task<bool> UpdateJournalAsync(Jurnal jurnal, int Id);
        Task<bool> DeleteJournalAsync(Jurnal jurnal);
    }
}
