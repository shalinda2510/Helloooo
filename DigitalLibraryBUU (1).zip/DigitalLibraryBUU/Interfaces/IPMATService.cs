﻿using DigitalLibraryBUU.Models;

namespace DigitalLibraryBUU.Services
{
    public interface IPMATService
    {
        List<Pmat> pmat { get; set; }

        Task<List<Pmat>> GetAllPMATAsync();
        Task<Pmat> GetPMATAsync(int Id);
        Task<bool> AddPMATAsync(Pmat pmat);
        Task<bool> UpdatePMATAsync(Pmat pmat, int Id);
        Task<bool> DeletePMATAsync(Pmat pmat);
    }
}
