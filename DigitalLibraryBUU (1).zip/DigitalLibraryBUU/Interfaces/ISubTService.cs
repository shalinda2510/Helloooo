﻿using DigitalLibraryBUU.Models;

namespace DigitalLibraryBUU.Services
{
    public interface ISubTService
    {
        List<Subtopical> SubT { get; set; }

        Task<List<Subtopical>> GetAllSubTAsync();
        Task<Subtopical> GetSubTAsync(int Id);
        Task<bool> AddSubTAsync(Subtopical subT);
        Task<bool> UpdateSubTAsync(Subtopical subT,int Id);
        Task<bool> DeleteSubTAsync(Subtopical subT);
        
        
    }
}
