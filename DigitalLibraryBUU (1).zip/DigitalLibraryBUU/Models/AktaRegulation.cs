﻿using System;
using System.Collections.Generic;

namespace DigitalLibraryBUU.Models;

public partial class AktaRegulation
{
    public int Id { get; set; }

    public string? ActNo { get; set; }

    public string? RegulationNo { get; set; }

    public string? RegulationTitle { get; set; }

    public string? Notes { get; set; }

    public DateTime? EntryDate { get; set; }
}
