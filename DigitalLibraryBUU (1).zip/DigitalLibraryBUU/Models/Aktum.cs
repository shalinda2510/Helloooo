﻿using System;
using System.Collections.Generic;

namespace DigitalLibraryBUU.Models;

public partial class Aktum
{
    public int Id { get; set; }

    public string ActNo { get; set; } = null!;

    public string? ActMonth { get; set; }

    public string? ActYear { get; set; }

    public DateTime? Cif { get; set; }

    public string? Title { get; set; }

    public string? Publisher { get; set; }

    public string? Series { get; set; }

    public string? CopyNumber { get; set; }

    public string? Location { get; set; }

    public string? Keadaan { get; set; }

    public DateTime? EntryDate { get; set; }

    public string? Notes { get; set; }
}
