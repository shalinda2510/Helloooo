﻿using System;
using System.Collections.Generic;

namespace DigitalLibraryBUU.Models;

public partial class AmendmentAktum
{
    public int Id { get; set; }

    public string? ActNo { get; set; }

    public string? AmendmentNo { get; set; }

    public string? AmendmentTitle { get; set; }

    public string? AmendmentYear { get; set; }

    public DateTime? EntryDate { get; set; }
}
