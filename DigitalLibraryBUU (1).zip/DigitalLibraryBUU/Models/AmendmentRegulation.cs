﻿using System;
using System.Collections.Generic;

namespace DigitalLibraryBUU.Models;

public partial class AmendmentRegulation
{
    public int Id { get; set; }

    public string? RegulationNo { get; set; }

    public string? AmendmentRegulationNo { get; set; }

    public string? AmendmentRegulationTitle { get; set; }

    public string? AmendmentRegulationYear { get; set; }

    public DateTime? EntryDate { get; set; }

    public DateTime? AmendmentCif { get; set; }
}
