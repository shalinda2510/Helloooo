﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DigitalLibraryBUU.Models;

public partial class Buku
{
    public int Id { get; set; }

    public string? TaggingId { get; set; }

    [Required(ErrorMessage = "ISBN wajib diisi")]
    public string Isbn { get; set; } = null!;

    [Required(ErrorMessage = "Penulis wajib diisi")]
    public string Author { get; set; } = null!;

    public string? AddedEntry { get; set; }

    public string? CorporateName { get; set; }

    [Required(ErrorMessage = "Tajuk/Judul wajib diisi")]
    public string? Title { get; set; }

    public string? Edition { get; set; }

    public string? Publisher { get; set; }

    [Required(ErrorMessage = "wajib diisi")]
    public string? CollationPage { get; set; }

    [Required(ErrorMessage = "wajib diisi")]
    public string? CollationHeight { get; set; }

    [Required(ErrorMessage = "wajib diisi")]
    public string? CollationWidth { get; set; }

    [Required(ErrorMessage = "wajib diisi")]
    public string? CollationIllustration { get; set; }

    public decimal? Price { get; set; }

    public string? Series { get; set; }

    public string? Notes { get; set; }

    [Required(ErrorMessage = "Subjek Topical wajib dipilih")]
    public string? SubjectTopical { get; set; }

    public string? CopyNumber { get; set; }

    [Required(ErrorMessage = "Lokasi wajib diisi")]
    public string? Location { get; set; }

    public string? Supplier { get; set; }

    public string? AccessNumber { get; set; }

    [Required(ErrorMessage = "Keadaan wajib dipilih")]
    public string? Keadaan { get; set; }

    public string? Category { get; set; }

    public DateTime? EntryDate { get; set; }
}
