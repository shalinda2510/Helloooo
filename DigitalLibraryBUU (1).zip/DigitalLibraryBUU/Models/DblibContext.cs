﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace DigitalLibraryBUU.Models;

public partial class DblibContext : DbContext
{
    public DblibContext()
    {
    }

    public DblibContext(DbContextOptions<DblibContext> options)
        : base(options)
    {
    }

    public virtual DbSet<AktaRegulation> AktaRegulations { get; set; }

    public virtual DbSet<Aktum> Akta { get; set; }

    public virtual DbSet<AmendmentAktum> AmendmentAkta { get; set; }

    public virtual DbSet<AmendmentRegulation> AmendmentRegulations { get; set; }

    public virtual DbSet<Buku> Bukus { get; set; }

    public virtual DbSet<Jurnal> Jurnals { get; set; }

    public virtual DbSet<Pmat> Pmats { get; set; }

    public virtual DbSet<RefBulan> RefBulans { get; set; }

    public virtual DbSet<Subtopical> Subtopicals { get; set; }

   protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AktaRegulation>(entity =>
        {
            entity.ToTable("akta_regulation");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.ActNo)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("act_no");
            entity.Property(e => e.EntryDate)
                .HasColumnType("date")
                .HasColumnName("entry_date");
            entity.Property(e => e.Notes)
                .IsUnicode(false)
                .HasColumnName("notes");
            entity.Property(e => e.RegulationNo)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("regulation_no");
            entity.Property(e => e.RegulationTitle)
                .IsUnicode(false)
                .HasColumnName("regulation_title");
        });

        modelBuilder.Entity<Aktum>(entity =>
        {
            entity.ToTable("akta");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.ActMonth)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("act_month");
            entity.Property(e => e.ActNo)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("act_no");
            entity.Property(e => e.ActYear)
                .HasMaxLength(4)
                .IsUnicode(false)
                .HasColumnName("act_year");
            entity.Property(e => e.Cif)
                .HasColumnType("date")
                .HasColumnName("cif");
            entity.Property(e => e.CopyNumber)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("copy_number");
            entity.Property(e => e.EntryDate)
                .HasColumnType("date")
                .HasColumnName("entry_date");
            entity.Property(e => e.Keadaan)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("keadaan");
            entity.Property(e => e.Location)
                .IsUnicode(false)
                .HasColumnName("location");
            entity.Property(e => e.Notes)
                .IsUnicode(false)
                .HasColumnName("notes");
            entity.Property(e => e.Publisher)
                .IsUnicode(false)
                .HasColumnName("publisher");
            entity.Property(e => e.Series)
                .IsUnicode(false)
                .HasColumnName("series");
            entity.Property(e => e.Title)
                .IsUnicode(false)
                .HasColumnName("title");
        });

        modelBuilder.Entity<AmendmentAktum>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_amendmend_akta");

            entity.ToTable("amendment_akta");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.ActNo)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("act_no");
            entity.Property(e => e.AmendmentNo)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("amendment_no");
            entity.Property(e => e.AmendmentTitle)
                .IsUnicode(false)
                .HasColumnName("amendment_title");
            entity.Property(e => e.AmendmentYear)
                .HasMaxLength(4)
                .IsUnicode(false)
                .HasColumnName("amendment_year");
            entity.Property(e => e.EntryDate)
                .HasColumnType("date")
                .HasColumnName("entry_date");
        });

        modelBuilder.Entity<AmendmentRegulation>(entity =>
        {
            entity.ToTable("amendment_regulation");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.AmendmentCif)
                .HasColumnType("date")
                .HasColumnName("amendment_cif");
            entity.Property(e => e.AmendmentRegulationNo)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("amendment_regulation_no");
            entity.Property(e => e.AmendmentRegulationTitle)
                .IsUnicode(false)
                .HasColumnName("amendment_regulation_title");
            entity.Property(e => e.AmendmentRegulationYear)
                .HasMaxLength(4)
                .IsUnicode(false)
                .HasColumnName("amendment_regulation_year");
            entity.Property(e => e.EntryDate)
                .HasColumnType("date")
                .HasColumnName("entry_date");
            entity.Property(e => e.RegulationNo)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("regulation_no");
        });

        modelBuilder.Entity<Buku>(entity =>
        {
            entity.ToTable("buku");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.AccessNumber)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("access_number");
            entity.Property(e => e.AddedEntry)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("added_entry");
            entity.Property(e => e.Author)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("author");
            entity.Property(e => e.Category)
                .HasMaxLength(4)
                .IsUnicode(false)
                .HasColumnName("category");
            entity.Property(e => e.CollationHeight)
                .HasMaxLength(4)
                .IsUnicode(false)
                .HasColumnName("collation_height");
            entity.Property(e => e.CollationIllustration)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("collation_illustration");
            entity.Property(e => e.CollationPage)
                .HasMaxLength(5)
                .IsUnicode(false)
                .HasColumnName("collation_page");
            entity.Property(e => e.CollationWidth)
                .HasMaxLength(4)
                .IsUnicode(false)
                .HasColumnName("collation_width");
            entity.Property(e => e.CopyNumber)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("copy_number");
            entity.Property(e => e.CorporateName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("corporate_name");
            entity.Property(e => e.Edition)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("edition");
            entity.Property(e => e.EntryDate)
                .HasColumnType("date")
                .HasColumnName("entry_date");
            entity.Property(e => e.Isbn)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("isbn");
            entity.Property(e => e.Keadaan)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("keadaan");
            entity.Property(e => e.Location)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("location");
            entity.Property(e => e.Notes)
                .IsUnicode(false)
                .HasColumnName("notes");
            entity.Property(e => e.Price)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("price");
            entity.Property(e => e.Publisher)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("publisher");
            entity.Property(e => e.Series)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("series");
            entity.Property(e => e.SubjectTopical)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("subject_topical");
            entity.Property(e => e.Supplier)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("supplier");
            entity.Property(e => e.TaggingId)
                .HasMaxLength(9)
                .IsUnicode(false)
                .HasColumnName("tagging_id");
            entity.Property(e => e.Title)
                .IsUnicode(false)
                .HasColumnName("title");
        });

        modelBuilder.Entity<Jurnal>(entity =>
        {
            entity.ToTable("jurnal");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.AccessNumber)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("access_number");
            entity.Property(e => e.AddedEntry)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("added_entry");
            entity.Property(e => e.Author)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("author");
            entity.Property(e => e.Category)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("category");
            entity.Property(e => e.CollationHeight)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("collation_height");
            entity.Property(e => e.CollationPage)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("collation_page");
            entity.Property(e => e.CollationWidth)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("collation_width");
            entity.Property(e => e.CopyNumber)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("copy_number");
            entity.Property(e => e.EntryDate)
                .HasColumnType("date")
                .HasColumnName("entry_date");
            entity.Property(e => e.Isbn)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("isbn");
            entity.Property(e => e.Issn)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("issn");
            entity.Property(e => e.Keadaan)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("keadaan");
            entity.Property(e => e.Location)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("location");
            entity.Property(e => e.Notes)
                .IsUnicode(false)
                .HasColumnName("notes");
            entity.Property(e => e.Price)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("price");
            entity.Property(e => e.Publisher)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("publisher");
            entity.Property(e => e.Series)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("series");
            entity.Property(e => e.SubjectTopical)
                .HasMaxLength(45)
                .IsUnicode(false)
                .HasColumnName("subject_topical");
            entity.Property(e => e.Supplier)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("supplier");
            entity.Property(e => e.Title)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("title");
        });

        modelBuilder.Entity<Pmat>(entity =>
        {
            entity.ToTable("pmat");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CopyNo)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("copy_no");
            entity.Property(e => e.DatePublisher)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("date_publisher");
            entity.Property(e => e.EntryDate)
                .HasColumnType("date")
                .HasColumnName("entry_date");
            entity.Property(e => e.Issue)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("issue");
            entity.Property(e => e.Keadaan)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("keadaan");
            entity.Property(e => e.Notes)
                .IsUnicode(false)
                .HasColumnName("notes");
            entity.Property(e => e.PmatCif)
                .HasColumnType("date")
                .HasColumnName("pmat_cif");
            entity.Property(e => e.PmatConsent)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("pmat_consent");
            entity.Property(e => e.PmatNo)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("pmat_no");
            entity.Property(e => e.PmatYear)
                .HasMaxLength(4)
                .IsUnicode(false)
                .HasColumnName("pmat_year");
            entity.Property(e => e.Title)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("title");
        });

        modelBuilder.Entity<RefBulan>(entity =>
        {
            entity.ToTable("refBulan");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Keterangan)
                .HasMaxLength(10)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Subtopical>(entity =>
        {
            entity.ToTable("subtopical");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.SubjectTopical)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("subject_topical");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
