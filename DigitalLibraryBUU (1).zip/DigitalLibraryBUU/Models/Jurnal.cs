﻿using System;
using System.Collections.Generic;

namespace DigitalLibraryBUU.Models;

public partial class Jurnal
{
    public int Id { get; set; }

    public string? AccessNumber { get; set; }

    public string? Isbn { get; set; }

    public string? Issn { get; set; }

    public string? Author { get; set; }

    public string? AddedEntry { get; set; }

    public string? Title { get; set; }

    public string? Publisher { get; set; }

    public decimal? Price { get; set; }

    public string? Series { get; set; }

    public string? Notes { get; set; }

    public string? SubjectTopical { get; set; }

    public string? CopyNumber { get; set; }

    public string? Location { get; set; }

    public string? Supplier { get; set; }

    public string? CollationPage { get; set; }

    public string? CollationHeight { get; set; }

    public string? CollationWidth { get; set; }

    public string? Keadaan { get; set; }

    public string? Category { get; set; }

    public DateTime? EntryDate { get; set; }
}
