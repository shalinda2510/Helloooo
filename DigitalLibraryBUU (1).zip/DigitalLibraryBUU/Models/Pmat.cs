﻿using System;
using System.Collections.Generic;

namespace DigitalLibraryBUU.Models;

public partial class Pmat
{
    public int Id { get; set; }

    public string? Issue { get; set; }

    public string? PmatNo { get; set; }

    public string? Title { get; set; }

    public string? PmatYear { get; set; }

    public string? PmatConsent { get; set; }

    public DateTime? PmatCif { get; set; }

    public string? DatePublisher { get; set; }

    public string? CopyNo { get; set; }

    public string? Keadaan { get; set; }

    public string? Notes { get; set; }

    public DateTime? EntryDate { get; set; }
}
