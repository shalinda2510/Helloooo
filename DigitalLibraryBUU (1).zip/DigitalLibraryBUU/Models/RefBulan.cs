﻿using System;
using System.Collections.Generic;

namespace DigitalLibraryBUU.Models;

public partial class RefBulan
{
    public int Id { get; set; }

    public string? Keterangan { get; set; }
}
