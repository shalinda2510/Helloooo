﻿using System;
using System.Collections.Generic;

namespace DigitalLibraryBUU.Models;

public partial class Subtopical
{
    public int Id { get; set; }

    public string? SubjectTopical { get; set; }
}
