﻿using DigitalLibraryBUU.Models;
using Microsoft.EntityFrameworkCore;

namespace DigitalLibraryBUU.Services
{
    public class AktaService : IAktaService
    {
        public List<Aktum> Akta { get; set; } = new List<Aktum>();

        private readonly DblibContext _dbContext;

        public AktaService(DblibContext context)
        {
            _dbContext = context;
        }

        public async Task<bool> AddAktaAsync(Aktum Akta)
        {
            await _dbContext.Akta.AddAsync(Akta);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAktaAsync(Aktum Akta)
        {
            _dbContext.Remove(Akta);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<Aktum> GetAktaAsync(int Id)
        {
            Aktum Akta = await _dbContext.Akta.FirstOrDefaultAsync(c => c.Id.Equals(Id));
            return Akta;
        }

        public async Task<List<Aktum>> GetAllAktaAsync()
        {
            return await _dbContext.Akta.OrderBy(i => i.Id).ToListAsync();
        }

        public async Task<bool> UpdateAktaAsync(Aktum Akta, int Id)
        {
            _dbContext.Akta.Update(Akta);
            await _dbContext.SaveChangesAsync();
            return true;
        }
    }
}
