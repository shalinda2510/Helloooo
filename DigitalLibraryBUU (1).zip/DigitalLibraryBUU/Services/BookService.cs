﻿using DigitalLibraryBUU.Models;
using DigitalLibraryBUU.Interfaces;
//using DigitalLibraryBUU.Pages.Book;
using Microsoft.EntityFrameworkCore;

namespace DigitalLibraryBUU.Services
{
    public class BookService : IBookService
    {
        public List<Buku> Bukus { get ; set; } = new List<Buku>();

        private readonly DblibContext _dbContext;

        public BookService(DblibContext context)
        {
            _dbContext = context;
        }

        #region Insert Book
        public async Task<bool> AddBookAsync(Buku buku)
        {
            await _dbContext.Bukus.AddAsync(buku);
            await _dbContext.SaveChangesAsync();
            return true;
        }
        #endregion

        #region Update Book
        public async Task<bool> UpdateBookAsync(Buku buku, int Id)
        {
            _dbContext.Bukus.Update(buku);
            await _dbContext.SaveChangesAsync();
            return true;
        }
        #endregion

        #region Delete Book
        public async Task<bool> DeleteBookAsync(Buku buku)
        {
            _dbContext.Remove(buku);
            await _dbContext.SaveChangesAsync();
            return true;
        }
        #endregion

        #region Get Book by Id
        public async Task<Buku> GetBookAsync(int Id)
        {
            Buku buku = await _dbContext.Bukus.FirstOrDefaultAsync(c => c.Id.Equals(Id));
            return buku;
        }
        #endregion

        #region Get List of Books
        public async Task<List<Buku>> GetAllBooksAsync()
        {
            return await _dbContext.Bukus.ToListAsync();
        }
        #endregion

        
    }
}
