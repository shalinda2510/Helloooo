﻿using DigitalLibraryBUU.Interfaces;
using DigitalLibraryBUU.Models;
using Microsoft.EntityFrameworkCore;

namespace DigitalLibraryBUU.Services
{
    public class JournalService : IJournalService

    {
        public List<Jurnal> jurnal { get; set; } = new List<Jurnal>();

        private readonly DblibContext _dbContext;

        public JournalService(DblibContext context)
        {
            _dbContext = context;
        }

        public async Task<bool> AddJournalAsync(Jurnal jurnal)
        {
            await _dbContext.Jurnals.AddAsync(jurnal);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteJournalAsync(Jurnal jurnal)
        {
            _dbContext.Remove(jurnal);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<List<Jurnal>> GetAllJournalAsync()
        {
            return await _dbContext.Jurnals.ToListAsync();
        }

        public async Task<Jurnal> GetJournalAsync(int Id)
        {
            Jurnal jurnal = await _dbContext.Jurnals.FirstOrDefaultAsync(c => c.Id.Equals(Id));
            return jurnal;
        }

        public async Task<bool> UpdateJournalAsync(Jurnal jurnal, int Id)
        {
            _dbContext.Jurnals.Update(jurnal);
            await _dbContext.SaveChangesAsync();
            return true;
        }
    }
}
