﻿using DigitalLibraryBUU.Models;
using Microsoft.EntityFrameworkCore;

namespace DigitalLibraryBUU.Services
{
    public class PMATService : IPMATService
    {
        public List<Pmat> pmat { get; set; } = new List<Pmat>();

        private readonly DblibContext _dbContext;

        public PMATService(DblibContext context)
        {
            _dbContext = context;
        }

        public async Task<bool> AddPMATAsync(Pmat pmat)
        {
            await _dbContext.Pmats.AddAsync(pmat);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeletePMATAsync(Pmat pmat)
        {
            _dbContext.Remove(pmat);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<List<Pmat>> GetAllPMATAsync()
        {
            return await _dbContext.Pmats.ToListAsync();
        }

        public async Task<Pmat> GetPMATAsync(int Id)
        {
            Pmat pmat = await _dbContext.Pmats.FirstOrDefaultAsync(c => c.Id.Equals(Id));
            return pmat;
        }

        public async Task<bool> UpdatePMATAsync(Pmat pmat, int Id)
        {
            _dbContext.Pmats.Update(pmat);
            await _dbContext.SaveChangesAsync();
            return true;
        }
    }
}
