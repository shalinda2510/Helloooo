﻿using DigitalLibraryBUU.Models;
using Microsoft.EntityFrameworkCore;

namespace DigitalLibraryBUU.Services
{
    public class SubTService : ISubTService
    {
        public List<Subtopical> SubT { get; set; } = new List<Subtopical>();

        private readonly DblibContext _dbContext;

        public SubTService(DblibContext context)
        {
            _dbContext = context;
        }

        public async Task<bool> AddSubTAsync(Subtopical subT)
        {
            await _dbContext.Subtopicals.AddAsync(subT);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteSubTAsync(Subtopical subT)
        {
            _dbContext.Remove(subT);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<List<Subtopical>> GetAllSubTAsync()
        {
            return await _dbContext.Subtopicals.OrderBy(i=> i.SubjectTopical).ToListAsync();
        }

        public async Task<Subtopical> GetSubTAsync(int Id)
        {
            Subtopical subT = await _dbContext.Subtopicals.FirstOrDefaultAsync(c => c.Id.Equals(Id));
            return subT;
        }

        public async Task<bool> UpdateSubTAsync(Subtopical subT, int Id)
        {
            _dbContext.Subtopicals.Update(subT);
            await _dbContext.SaveChangesAsync();
            return true;
        }
    }
}
